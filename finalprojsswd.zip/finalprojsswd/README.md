# TO-DO README

Idea:

Maintaining all of your vehicle repair needs

<br>

Motivation:
<br>
<br>
If one has ever owned a car or looking to own a car, they must understand the complexity of its repairs. Throughout the course of one’s life there will always be the need for maintenance on your vehicle. Sooner or later you will have to bring your car into a shop and get it fixed in order for you and others on the road to be safe. Thus, I will be developing a website that allows users to create profiles in order for auto repair businesses to recognize their clients, schedule appointments, and add in their vehicle information.
I personally have been working in a mechanic shop for 8 years now. Throughout the years people will always be calling several times but do not understand that us mechanics are working and cannot be around the phone to answer. This creates a dilemma because if the phones are not being picked up and people urgently need their vehicles fixed, then a lot of walk-ins occur. This causes immense frustration and stress due to the amount of work on hand that needs to be completed in a set time frame of the daily work schedule.

<br>

Application:
<br>
<br>
This website will be a page where users can create accounts in order to be able to add in their vehicle's information for us as the 
professionals to get an idea of certain issues. This site will allow users to adjust their history and vehicles by setting up all their information 
for their specific vehicle such as make, model, and year. By giving us the information, we can figure out the problem. Thus being able to 
move forward and schedule a time to bring in the vehicle in for maintenance, inspection, or suggestions/offers, This makes it easier for 
the business and its clients and everyone will be satisfied without stressful mechanic shop situations.

<br>

Application Name:

                    The Pit Stop	

