package edu.neiu.finalprojsswd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalprojsswdApplicationTests {

    @Test
    void contextLoads() {
    }

}
