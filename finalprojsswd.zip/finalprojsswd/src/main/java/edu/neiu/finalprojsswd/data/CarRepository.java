package edu.neiu.finalprojsswd.data;

import edu.neiu.finalprojsswd.models.Car;
import org.springframework.data.repository.CrudRepository;

public interface CarRepository extends CrudRepository<Car, Long> {

}
